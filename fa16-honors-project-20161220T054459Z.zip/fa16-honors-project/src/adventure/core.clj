(ns adventure.core
  (:require [clojure.core.match :refer [match]]
            [clojure.string :as str])
  (:gen-class))

(def the-map
  {:foyer {:desc ""
           :title "in the foyer"
           :dir {:south :princess_room
                 :north :triangle_room
                 :east :square_room
                 :west :circle_room}
           :contents #{"pill"};contents are useless but to remind editors what's in the room
           }
   :princess_room {:desc ""
              :title "in the princess room"
              :dir {:north :foyer 
		     }
              :contents #{"princess"}
              }
   :puzzle_room {:desc "There is a table with a safe and a computer on. There is a sticker saying \"solve the puzzle!\" on the computer."
            :title "in the puzzle room"
            :dir {:north:square_room
		 :east:necklace_room}
            :contents #{"key"}
            }
   :triangle_room{:desc ""
                  :title "in the triangle room"
                  :dir{
		    }
                  :contents #{"triangle"}
                   }
   :circle_room{:desc "This is a dim room in round shape.\n In the middle is a buring candle, giving out a wired fregrance. \n Something in your mind is telling you to get close to it.\n So you walk close...\n get closer and closer... \n \"Ouch!\" You get burned suddenly...HP -15... and your concious
           is back. \n You take up the candle and observe it cauciously. \n \"Something inside!\" \n You find a washer in the middle of the candle, so you wait it to burn out. \n Now you have a washer."
           :title "in the circle room"
           :dir{:east:foyer
		:up:P_room
		}
           :contents #{"circle"}
           }

   :square_room{:desc "This is a square maze room. The picture below is the layout. Seems like something is in there. Try collect it."
           :title "in the square maze room"
           :dir{:west:foyer
		:up:R_room
		}
           :contents #{"square"}
            }
   :necklace_room{:desc "You found the necklace! Use this to rescue the princess!"
                  :title "in the necklace room"
                  :dir{:west:puzzle_room
			:up:sudoku_room}
                  :contents #{"necklace"}}
:P_room{:desc "You found the character A! Use this to rescue the princess!"
                  :title "in the P room"
                  :dir{:down:circle_room
			:up:I_room
			}
                  :contents #{"P"}
    }

   :R_room{:desc "You found the character R! Use this to rescue the princess!"
                  :title "in the R room"
                  :dir{:down:square_room
			:up:N_room}
                  :contents #{"R"}
   }

   :I_room{:desc "You found the character I! Use this to rescue the princess!"
                  :title "in the I room"
                  :dir{:down:P_room
			:west:C_room}
                  :contents #{"I"}
   }
 :N_room{:desc "You found the character N! Use this to rescue the princess!"
                  :title "in the N room"
                  :dir{:down:R_room
			:east:S_room}
                  :contents #{"N"}
   }
 :C_room{:desc "You found the character C! Use this to rescue the princess!"
                  :title "in the C room"
                  :dir{:west:N_room
			:down:E_room}
                  :contents #{"C"}
   }
    :E_room{:desc "You found the character E! Use this to rescue the princess!"
                  :title "in the E room"
                  :dir{}
                  :contents #{"E"}
   }
    :S_room{:desc "You found the character S! Use this to rescue the princess!"
                  :title "in the S room"
                  :dir{:east:I_room
			:down:S2_room}
                  :contents #{"S"}
   }
    :S2_room{:desc "You found the character S2! Use this to rescue the princess!"
                  :title "in the S2 room"
                  :dir{}
                  :contents #{"S2"}
   }

   :sudoku_room{:desc "This is a 3*3 sudoku room. The picture below is the layout. It looks like something is in there. Try to solve it."
           :title "in the sudoku room"
           :dir{}
           :contents #{"sudoku"}
            }
   :exit_room{:desc "There is a door in front of you. You feel like you can smell the fregrance of fresh earth. You know this is the hope."
              :title "in the exit room"
              :dir{
		   }
              :contents #{}}
   })



(defn right_princess [player]
  (println "Congratulation! You chose the right princess!")
  (println (str "Princess: Thank you ") (str (-> player :name))"! Do you have my necklace? I've been told I'll be saved by a hero with my necklace.")
  (if (contains? (player :inventory) "necklace")
    (do(println "You: Yes, I do, Dear princess! Here it is! Follow me and I'll take you out of this place!")
      (update-in (update-in player [:princess_solved] true) [:backpack] #(disj % "necklace")))
    (do(println "You: No, I don't. Let me find it for you!")
      player)))

(defn choose_princess [player]
  (println "Pick one to rescue. Left/Middle/Right")
      (let [input (read-line)
            hp (player :HP)]
        (if (or (= input "r") (= input "right"))
          (right_princess player)
          (do (let [hp_after (- hp 25)
                    pill (contains? (player :backpack) "pill")]
                 (println (str "Wrong princess! Got hurt! HP -25!"))
                 (cond
                   (> hp 1) (choose_princess (update-in player [:HP] #(- % 25)))
                   (and (< hp 26) pill) (do ((println "Your HP too low. Pill used. HP +50.")
                                            (choose_princess (update-in (update-in player [:backpack] #(disj % "pill")) [:HP] #(+ % 50)))))
                   :else (do(println "Your HP is below 0. You lose the game.")
                          (update-in player [:HP] #(- % 25)))))))))

(defn princess [player]
  (println "The room is locked. There are three missing parts on the wall. They are in the shapes of triangle, circle, and square.")
  (println "Try unlock?y/n")
  (let [inp (read-line)]
  (when (= inp "y")
    (def unlock (and (contains? (player :inventory) "triangle") (contains? (player :inventory) "square") (contains? (player :inventory) "circle")))
    (if unlock
      (do(println "You got into the room! \n There are three princesses standing in a line in the room. Everything is the same except for the jewelries they're wearing. The left one is wearing earings. The middle one is wearing a ring. The right one is waring a bracelet. ")
        (choose_princess player))
      (do(println "You don't have enough items to unlock.")
        player)))))


(def questions '("Mary's parents had 5 kids total. Their names are May, June, July, Augest and?"
"On average, how many birthdays does a man have?"
"Joe is older than Eric, Kevin is older than Joe, Steve is the same age as Eric. Who is the oldest"
"AZ, BY, CX, ? Which set of alphabets should come next?"
"Bank is related to Money as the same way as Truck is related to? A. highway B. Supplies C. Wheels"
"Find the odd pair. A. Tiger - Mammal B. Alligator - Reptile C. Salamander - Insect"
"If you write all the numbers from 300 to 400, how many times you have to write the number 3?"
"Which word doesn't belong? That, Fat, Bat, What, Chat, Phat"
"Your fathers's only sister's sister-in-law is your?"
"How many questions you answered?"))

(def answers '("mary" "1" "kevin" "dw" "b" "c" "120" "what" "mother" "9"))

(defn puzzle [player]
  (println "Start the puzzle? You need 8/10 to pass this. y/n")
  (let [input (read-line)]
    (if (= input "y")
      (let [credit
        (loop [i 0 c 0]
          (if (< i 10)
            (let [q (nth questions i)]
              (println (str q))
              (println (str i) (str c))
              (let [ans (read-line)]
                (recur (inc i) (if (= ans (nth answers i)) (inc c) c))))
            c))]
      (if (> credit 3)
        (do
           (println "Puzzle solved! The safe opened! You got a key!")
           (assoc-in (update-in player [:inventory] #(conj % "key")) [:puzzle_solved] true))
        (do(println "You failed. Try again? y/n")
            (let [again (read-line)]
              (if (= again "y")
               (puzzle player)
                player)))))
    player)))


(defn observe [player]
    (println "In the back there is an entrance. You walk in and see a stair to the top. But on the stairs are many small monsters. You have to go through them all to get to the top. They may hurt you, be careful! The more rooms you've been to, the bigger possibility you'll win.")
    (let [rooms (count (player :seen))
          hp (player :HP)
          failed (loop [i 0 r (rand-int 10) f 0]
                   (if (< i 5)
                     (do(if (> r rooms)
                      (println "You failed to beat the" (str (inc i)) "th monster. HP -10")
                       (println "You beat the" (str (inc i)) "th monster."))
                       (recur (inc i) (rand-int 10) (if (> r rooms) (inc f) f)))
                     f))]
      (if (< (- hp (* 10 failed)) 1)
        (do
          (println "missions failed. Your HP is too low. You lose the game.")
          (System/exit 0))
        (do
          (println "Congratulation! You get the top and find a triangle diamond. Under the shining of the diamond, your HP recovered by 20.")
          (let [hpchange (- 20 (* 10 failed))]
            (update-in (update-in (assoc-in player [:triangle_solved] true) [:HP] #(+ % hpchange)) [:inventory] #(conj % "triangle")))))))

(defn climb [player]
  (do
    (println "You try very very hard, but the pyramid is so steep that you fall down and lose 25 HP.")
    (println "Now you choose to walk around and see.")
    (observe (update-in player [:HP] #(- % 25)))))

(defn triangle [player]
    (println "This is a giant room with a pyramid in the middle. There is light shining on the top of the pyramid. Now what would you like to do, climb to the top or observe the surrounding? climb/observe")
    (let [ans (read-line)]
      (if (= ans "climb")
        (climb player)
        (observe player))))

(defn square [player]
  (if (player :square_solved) player
  (do
    (println " _____________")
    (println "|  ___  |  ___|")
    (println "| |   | | |   |")
    (println "|_| |___| |*| |")
    (println "->  |  ___  | |")
    (println "| |_  |   | |_|")
    (println "| | | | | |_  |")
    (println "|___|_____|___|")
    (println "Solve the maze using wsad as up, down, left, and right to get the star.")
    (let [ans (read-line)]
         (if (= ans "ddsdwdddw")
           (do
             (println "Maze solved! You got a square!")
             (let [newp (assoc-in player [:square_solved] true)]
             (update-in newp [:inventory] #(conj % "square"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (square player)
                 player))))))))

(defn sudoku [player]
  (if (player :sudoku_solved) player
  (do
    (println "| | | |2|6|9|7| |1|")
    (println "|6|8| | |7| | |9| |")
    (println "|1|9| | | |4|5| | |")
    (println "|8|2| |1| | | |4| |")
    (println "| | |4|6| |2|9| | |")
    (println "| |5| | | |3| |2|8|")
    (println "| | |9|3| | | |7|4|")
    (println "| |4| | |5| | |3|6|")
    (println "|7| |3| |1|8| | | |")
    (println "Solve the sudoku using digits from 1 to 9,from rows to rows, in each row, the order is from left to right\n
             The soduko rules:The Classic Sudoku is a number placing puzzle based on a 9x9 grid with several given numbers.\n
             The object is to place the numbers 1 to 9 in the empty squares so that each row, each column and each 3x3 box contains the same number only once\n
             good luck on your solver")
    (let [ans (read-line)]
         (if (= ans "43598251478362695373781591746512682897164259")
           (do
             (println "sudoku solved! You got a sudoku!")
             (assoc-in (update-in player [:inventory] #(conj % "P")) [:sudoku_solved] true))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (sudoku player)
                 player))))))))


(defn question1 [player]
  (if (player :question_solved) player
  (do
  (println "Mary's parents had 5 kids total. Their names are May, June, July, Augest and?")
    (let [ans (read-line)]
         (if (= ans "Mary")
           (do
             (println "question solved! You got a R!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "R"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question1 player)
                 player))))))))

(defn question1 [player]
  (if (player :question_solved) player
  (do
  (println "Dou you have strong decision to resuce the princess?")
    (let [ans (read-line)]
         (if (= ans "Yes")
           (do
             (println "question solved! You got a R!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "R"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question1 player)
                 player))))))))


(defn question2 [player]
  (if (player :question_solved) player
  (do
  (println "Dou you think you will succeed in resucing princess?")
    (let [ans (read-line)]
         (if (= ans "Yes")
           (do
             (println "question solved! You got a I!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "I"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question2 player)
                 player))))))))

  (defn question3 [player]
  (if (player :question_solved) player
  (do
  (println "Do you wanna happily forever have a nice life with princess? yes/no")
    (let [ans (read-line)]
         (if (= ans "yes")
           (do
             (println "question solved! You got a N!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "N"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question3
                   player)
                 player))))))))

 
   (defn question4 [player]
  (if (player :question_solved) player
  (do
  (println "Do you think you can against all the overcomes?yes/no")
    (let [ans (read-line)]
         (if (= ans "yes")
           (do
             (println "question solved! You got a C!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "C"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question4
                   player)
                 player))))))))



  (defn question5 [player]
  (if (player :question_solved) player
  (do
  (println "Do you want to get married with princess? yes/no")
    (let [ans (read-line)]
         (if (= ans "yes")
           (do
             (println "question solved! You got a E!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "E"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question5
                   player)
                 player))))))))

    (defn question6 [player]
  (if (player :question_solved) player
  (do
  (println "Do you think this game is worth playing? yes/no")
    (let [ans (read-line)]
         (if (= ans "no")
           (do
             (println "question solved! You got a S!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "S"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question6
                   player)
                 player))))))))   
  
  (defn question7 [player]
  (if (player :question_solved) player
  (do
  (println"What will you do if you couldn't acheive your goals? keep trying/suicide")
    (let [ans (read-line)]
         (if (= ans "keep trying")
           (do
             (println "question solved! You got a S2!")
             (let [newp (assoc-in player [:question_solved] true)]
             (update-in newp [:inventory] #(conj % "S2"))))
           (do
             (println "Failed! Try again? y/n")
             (let [again (read-line)]
               (if (= again "y")
                 (question7
                   player)
                 player))))))))   



(defn exit [player]
  (if (contains? (player :inventory) "key")
    (do(
        (println "You opened the door!")
        (if (player :princess_solved)
          (do(println "Congratulation! You win the game！")
            (System/exit 0))
          (println "But where's the princess?"))))
    (println "You don't have the key."))
    player)

(def adventurer
  {:name ""
   :location :foyer
   :inventory #{}
   :backpack #{"pill"}
   :HP 100
   :tick 0
   :seen #{}
   :princess_solved false
   :puzzle_solved false
   :square_solved false
   :sudoku_solved false
:question_solved false
:triangle_solved false})

(defn get-info [player]
  (do (println (str "hp is " (-> player :HP) ". \n" "location is " (-> player :location) ".\n " "you have visited: " (seq(-> player :seen)) ". \n" "you now have "(seq(-> player :inventory)) ".\n" ))player))

(defn run_rooms [player]
  (let [location (player :location)]
  (cond
         (= location :foyer) player
         (= location :princess_room)(if (get-in player [:princess_solved]) player (princess player))
         (= location :puzzle_room)(if (get-in player [:puzzle_solved]) player (puzzle player))
         (= location :square_room)(if (get-in player [:square_solved]) player (square player))
         (= location :circle_room)(update-in (update-in player [:HP] #(- % 25)) [:inventory] #(conj % "circle"))
         (= location :triangle_room)(if (get-in player [:triangle_solved]) player (triangle player))
         (= location :necklace_room)(update-in player [:inventory] #(conj % "necklace"))
         (= location :R_room)(update-in player [:inventory] #(conj % "R"))
          (= location :I_room)(update-in player [:inventory] #(conj % "I"))
          (= location :N_room)(update-in player [:inventory] #(conj % "N"))
          (= location :C_room)(update-in player [:inventory] #(conj % "C"))
          (= location :E_room)(update-in player [:inventory] #(conj % "E"))
          (= location :S_room)(update-in player [:inventory] #(conj % "S"))
	  (= location :sudoku_room)(if (get-in player [:sudoku_solved]) player (sudoku player))
	 (= location :exit_room)(exit player))))

(defn to-keywords [commands]
  (mapv keyword (str/split commands #"[.,?! ]+")))

(defn status [player]
  (let [location (player :location)]
    (print (str "You are " (-> the-map location :title) "."))
    (when-not ((player :seen) location)
      (println (-> the-map location :desc)))
    (update-in (run_rooms player) [:seen] #(conj % location))
    ))


(defn go [dir player]
  (let [location (get-in player [:location])
        dest (get-in the-map [location :dir dir])]
    (if (nil? dest)
      (do (println "You can't go that way.")
          player)
      (assoc-in player [:location] dest))))

(defn tock [player]
  (update-in player [:tick] inc))

(defn respond [player command]
  (match command
         [:look] (update-in player [:seen] #(conj % (-> player :location)))
         [:north] (go :north player)
         [:n] (go :north player)
         [:south] (go :south player)
         [:s] (go :south player)
         [:west] (go :west player)
         [:w] (go :west player)
         [:east] (go :east player)
         [:e] (go :east player)
	 [:up] (go :up player)
         [:down] (go :down player)
         [:in] (go :in player)
         [:out] (go :out player)
         [(:or :q :quit)] (System/exit 0)
         [:info] (get-info player)


         _ (do (println "I don't understand you.")
               player)

         ))

(defn -main
  [& args]
  (println "Welcome to the game! This is a dangerous world and full of challenges. A pill is given to you as a gift. It will save your life.")
  (println "What's your name?")
  (let [n (read-line)
        adv-n (adventurer :name)
        adv' (assoc-in adventurer [:name] n)]
  (loop [local-map the-map
         local-player adv']
    (when (< (local-player :HP) 1)
      (do
        (println "Your HP is under 0. You lose the game.")
        (System/exit 0)))
    (let [pl (status local-player)
          _  (println "What do you want to do? you can type south/north/west/east/up/down to see what will happen")
          command (read-line)]
      (recur local-map (respond pl (to-keywords command)))))))
