# CS 296-25 Honors Project

This repository contains the code we did in class.  You can
use it as a starting point for your own project if you want.

## Installation

Do a `git clone git@gitlab-beta.engr.illinois.edu:mattox/fa16-honors-project.git` if you have uploaded your secure shell public key to gitlab.  Otherwise, use `git clone https://gitlab-beta.engr.illinois.edu/mattox/fa16-honors-project.git`

## Usage

The main file you want to edit is `src/adventure/core.clj`.

To run the program, use `lein run` from the command line.


## License

Copyright © 2016 Mattox Beckman, free for personal and educational use.

